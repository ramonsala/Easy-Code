1 - Build the ECDrv64 project.
2 - Then build the ECDrv64Test project.
3 - Run ECDrv64Test.exe (as an Administrator) and test the driver.
