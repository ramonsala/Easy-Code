1 - Build the ECPDriver project.
2 - Then build the ECPDrvTest project.
3 - Run ECPDrvTest.exe (as an Administrator) and test the driver.

For getting more examples of simple 32-bit drivers, enter the following address
in your browser:

https://easycode.cat/English/Download/ECDrivers.zip
